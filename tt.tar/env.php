<?php

namespace env;

#DATABASE
define("DBHOST", "localhost");
define("DBPOST", "3306");
define("DBLOGIN","Zavrik");
define("DBPASS","Zavrik_2008!");
define("DBNAME","zavrik");